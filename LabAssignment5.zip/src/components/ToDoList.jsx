import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ToDoList = () => {
  return (
    <View style={styles.container}>
      <Text>ToDo List Component</Text>
      {/* Your ToDo list items will go here */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
});

export default ToDoList;
