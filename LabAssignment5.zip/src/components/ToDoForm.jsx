import React from 'react';
import { View, Text, StyleSheet, TextInput, Button } from 'react-native';

const ToDoForm = () => {
  return (
    <View style={styles.container}>
      <TextInput style={styles.input} placeholder="Enter a new task" />
      <Button title="Add Task" onPress={() => {}} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
  },
});

export default ToDoForm;
