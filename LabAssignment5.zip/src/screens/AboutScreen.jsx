import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import MainLayout from '../layouts/MainLayout';

const AboutScreen = () => {
  const handlePress = () => {
    alert('Easter egg message!');
  };

  return (
    <MainLayout>
      <Text style={styles.text}>Name of the App</Text>
      <TouchableOpacity onPress={handlePress}>
        <Text style={styles.text}>Your Name</Text>
      </TouchableOpacity>
      <Text style={styles.text}>Current Date: {new Date().toLocaleDateString()}</Text>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: 18,
    marginBottom: 10,
  },
});

export default AboutScreen;
